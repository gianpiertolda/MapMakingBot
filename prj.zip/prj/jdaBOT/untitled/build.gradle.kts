plugins {
    id("java")
    id("application")
    id("com.github.johnrengelman.shadow") version "8.1.1"
}

group = "org.example"
version = "1.0.6"

repositories {
    mavenCentral()
}

dependencies {
    implementation("mysql:mysql-connector-java:8.0.33")
    implementation("net.dv8tion:JDA:5.2.1")
}

application {
    mainClass.set("org.example.Main")
}

tasks {
    shadowJar {
        manifest {
            attributes(
                "Main-Class" to "org.example.Main"
            )
        }
        archiveBaseName.set("untitled")
        archiveVersion.set("1.0.6")
        archiveClassifier.set("all")
        mergeServiceFiles()
    }
}

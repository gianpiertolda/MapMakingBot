package org.example;

import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.events.session.ReadyEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import org.example.DiscordCommands.CommandsManager;
import org.example.DiscordCommands.NationsDataCommands;
import org.example.DiscordCommands.NationPayment;
import org.example.DiscordCommands.YearUpdate;
import org.jetbrains.annotations.NotNull;

public class Listners extends ListenerAdapter {

    @Override
    public void onReady(@NotNull ReadyEvent event){
        JDA jda = event.getJDA();
        System.out.println("------------------");
        for (Guild g : jda.getGuilds() ){
            System.out.println(g.getName() + "\t" + g.getBotRole());
        }
        System.out.println("------------------\n");


        DatabaseLoader.printFullTable(("nations"));
        System.out.println();
        DatabaseLoader.printFullTable("provinces");

        CommandsManager.upsertAll(event);

    }
}

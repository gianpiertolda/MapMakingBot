package org.example;

public class Token {
    public static final String JDATOKEN = "MTI1NzMzOTU3MzE5ODEzMTI2MA.Gr2Y8K.Q8svE6cnsQfyvcIVrAB5EXN9QEy_6yXoLpu1j4";
    public static final String AdminRoleID = "1294702749585379378";
    public static final String MapGamingServerID = "1257344226614710273";

}

package org.example;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DatabaseLoader {
    private static final String URL = "jdbc:mysql://localhost:3306/nationsdb"; // DB name
    private static final String USER = "root"; // Username MySQL
    private static final String PASSWORD = ""; // Password MySQL

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public static void printFullTable(String tableName){
        String query = "SELECT * FROM " + tableName;

        try (Connection connection = getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            // Recupera il numero di colonne dalla tabella
            int columnCount = resultSet.getMetaData().getColumnCount();

            System.out.println(tableName + " :");
            System.out.println("------------------------------");

            // Stampa i risultati riga per riga
            while (resultSet.next()) {
                for (int i = 1; i <= columnCount; i++) { // Le colonne partono da 1
                    System.out.print(resultSet.getMetaData().getColumnName(i) + ": " + resultSet.getString(i) + " | ");
                }
                System.out.println(); // Riga successiva
            }

            System.out.println("------------------------------");

        } catch (Exception e) {
            System.err.println("Errore durante il recupero dei dati dalla tabella X: " + e.getMessage());
            e.printStackTrace();
        }

    }

    public static List<List<String>> ReturnQuery(String query){
        List<List<String>> results = new ArrayList<>();

        try (Connection connection = getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            // Recupera il numero di colonne dalla tabella
            int columnCount = resultSet.getMetaData().getColumnCount();

            // Stampa i risultati riga per riga
            while (resultSet.next()) {
                List<String> row = new ArrayList<>();
                for (int i = 1; i <= columnCount; i++) {
                    row.add(resultSet.getString(i)); // Aggiunge il valore alla riga
                }

                results.add(row);
            }


        } catch (Exception e) {
            System.err.println("Errore durante il recupero dei dati dalla tabella X: " + e.getMessage());
            e.printStackTrace();
        }

        return results;

    }

    public static int executeUpdate(String query) {
        int rowsAffected = 0; // Variabile per contare le righe modificate

        try (Connection connection = getConnection();
             Statement statement = connection.createStatement()) {

            rowsAffected = statement.executeUpdate(query); // Esegue la query di modifica
            System.out.println("Query eseguita con successo. Righe interessate: " + rowsAffected);

        } catch (Exception e) {
            System.err.println("Errore durante l'esecuzione della query: " + e.getMessage());
            e.printStackTrace();
        }

        return rowsAffected; // Ritorna il numero di righe modificate
    }

    public static int executeUpdateSimple(String query, Object... params) {
        int rowsAffected = 0;

        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            // Imposta i parametri nella query
            for (int i = 0; i < params.length; i++) {
                preparedStatement.setObject(i + 1, params[i]);
            }

            rowsAffected = preparedStatement.executeUpdate();
            System.out.println("Query OK. Affected Row: " + rowsAffected);

        } catch (Exception e) {
            System.err.println("Error during the execution of the Query " + e.getMessage());
            e.printStackTrace();
        }

        return rowsAffected;
    }


}

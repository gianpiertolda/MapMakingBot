package org.example.DiscordCommands;

import net.dv8tion.jda.api.events.session.ReadyEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import org.example.Token;
import org.jetbrains.annotations.NotNull;

public class CommandsManager extends ListenerAdapter {
    public static int upsertAll(@NotNull ReadyEvent event){
        try {
            NationPayment.UpsertPaymentCommands(event.getJDA().getGuildById(Token.MapGamingServerID));
            YearUpdate.UpsertTimerCommands(event.getJDA().getGuildById(Token.MapGamingServerID));
            NationsDataCommands.UpsertDataCommands(event.getJDA().getGuildById(Token.MapGamingServerID));

        }catch (Exception e){
            return -1;
        }
        return 1;
    }
}

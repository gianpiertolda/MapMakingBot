package org.example.DiscordCommands;

import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.events.Event;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.interactions.commands.OptionMapping;
import net.dv8tion.jda.api.interactions.commands.OptionType;
import net.dv8tion.jda.api.interactions.commands.build.OptionData;
import org.example.DatabaseLoader;

import java.util.List;

public class NationsDataCommands extends ListenerAdapter {
    public void onSlashCommandInteraction(SlashCommandInteractionEvent event){
        if(!(event.getName().equals("bankbalance") ) ){
            return;
        }
        if (event.getName().equals("bankbalance") ){
            String ID = event.getOption("nation").getAsString();
            if (ID.length() != 3){
                event.reply("please insert the nation **ID**").queue();
                return;
            }
            System.out.println(event.getUser().getEffectiveName() + " requested Bank balance for " + ID);
            String query = "SELECT Bank FROM nations WHERE  ID = '" + ID + "'";
            List<List<String>> Data = DatabaseLoader.ReturnQuery(query);
            if (Data == null || Data.isEmpty()){
                System.out.println("Failed");
                event.reply("No nation found with such ID: " + ID).queue();
                return;
            }

            double BankValue = Double.parseDouble(Data.get(0).get(0));
            query = "SELECT * FROM nations WHERE  ID = '" + ID + "'";
            Data = DatabaseLoader.ReturnQuery(query);
            String NatName = Data.get(0).get(1);
            event.reply("National bank of " + NatName + ": " + BankValue).queue();
            System.out.println("The operation succeeded, bank balance: " + BankValue + "\n");
        }

    }

    public static void UpsertDataCommands(Guild g){
        g.upsertCommand("bankbalance", "gets the amount of cash inside a nation bank using the nation ID").addOption(OptionType.STRING, "nation", "the ID of the nation who PAYS the amount", true).queue();
    }
}

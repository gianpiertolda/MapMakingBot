package org.example.DiscordCommands;

import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.interactions.Interaction;
import net.dv8tion.jda.api.interactions.commands.OptionType;
import net.dv8tion.jda.api.interactions.commands.build.OptionData;
import org.example.DatabaseLoader;
import org.example.Token;

import java.util.List;

public class YearUpdate extends ListenerAdapter {
    @Override
    public void onSlashCommandInteraction(SlashCommandInteractionEvent event) {
        if(!(event.getName().equals("forceyearudpate") || event.getName().equals("resetyear") || event.getName().equals("yearcheck") ) ){
            return;
        }

        if (event.getName().equals("forceyearudpate") ) {
            if (!event.getMember().getRoles().stream().anyMatch(role -> role.getId().equals(Token.AdminRoleID))) {
                event.reply("You are not allowed to do such action").queue();
                return;
            }
            //TODO
        }

        if (event.getName().equals("resetyear") ) {
            if (!event.getMember().getRoles().stream().anyMatch(role -> role.getId().equals(Token.AdminRoleID))) {
                event.reply("You are not allowed to do such action").queue();
                return;
            }
            //TODO
        }

        if (event.getName().equals("yearcheck") ) {
            if (!event.getMember().getRoles().stream().anyMatch(role -> role.getId().equals(Token.AdminRoleID))) {
                event.reply("You are not allowed to do such action").queue();
                return;
            }
            System.out.println(event.getUser().getEffectiveName() + " requested a year check: ");
            List<List<String>> NationsData = DatabaseLoader.ReturnQuery("SELECT * FROM nations");
            List<List<String>> ProvincesData = DatabaseLoader.ReturnQuery("SELECT * FROM provinces");
            int eco;
            String query = "UPDATE nations SET Bank = Bank + ? WHERE ID = ?";
            for (List<String> row : NationsData) {
                // cycling each nation:
                eco = CalculateTotalEconomyFromProvinces(row.get(0), ProvincesData);
                eco = eco - Integer.parseInt(row.get(4)) * 850;
                int rowsAffected =  DatabaseLoader.executeUpdateSimple(query, eco, row.get(0));
                System.out.println("updated: " + row.get(1));
            }

            event.reply("done correctly").queue();
        }
    }

    public static void UpsertTimerCommands(Guild g){
        g.upsertCommand("yearcheck", "makes all the update related to the new year without changing the timer towards the next one").queue();
        g.upsertCommand("forceyearudpate", "update the year, scaling to the next one").queue();
        g.upsertCommand("resetyear", "reset the current year, starting again from january 1st").queue();
    }

    public int CalculateTotalEconomyFromProvinces(String nationID, List<List<String>> prov){
        if (prov == null || prov.isEmpty() ){
            System.err.println("no provinces found");
            return -1;
        }

        int counter = 0;

        for (List<String> row : prov) {
            if (row != null && !row.isEmpty()) {
                String provinceNationId = row.get(1);
                if (provinceNationId.equals(nationID)) {
                    try {
                        counter += Double.parseDouble(row.get(4));
                    } catch (NumberFormatException e) {
                        System.err.println("Errore nel parsing del GDP per la provincia: " + row.get(2));
                    }
                }
            }

        }
        return counter;
    }
}

package org.example.DiscordCommands;

import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.interactions.commands.OptionMapping;
import net.dv8tion.jda.api.interactions.commands.OptionType;
import net.dv8tion.jda.api.interactions.commands.build.OptionData;
import org.example.DatabaseLoader;
import org.example.Token;

import java.util.List;


public class NationPayment extends ListenerAdapter {
    @Override
    public void onSlashCommandInteraction(SlashCommandInteractionEvent event) {
        if(!(event.getName().equals("forcepayment") || event.getName().equals("payment") || event.getName().equals("payment") ) ){
            return;
        }

        if (event.getName().equals("forcepayment") ){
            if (!event.getMember().getRoles().stream().anyMatch(role -> role.getId().equals(Token.AdminRoleID)) ) {
                event.reply("You are not allowed to do such action").queue();
                return;
            }
            OptionMapping PayerNat = event.getOption("nation1");
            OptionMapping ReceivingNat = event.getOption("nation2");
            OptionMapping amount = event.getOption("amount");


            System.out.println("forced nation payment: " + PayerNat.getAsString() + " payed " + amount.getAsInt() + " to " + ReceivingNat.getAsString() );

            String query = "UPDATE nations SET Bank = Bank - ? WHERE ID = ?";
            int rowsAffected = DatabaseLoader.executeUpdateSimple(query, amount.getAsInt(), PayerNat.getAsString());
            query = "UPDATE nations SET Bank = Bank + ? WHERE ID = ?";
            rowsAffected += DatabaseLoader.executeUpdateSimple(query, amount.getAsInt(), ReceivingNat.getAsString());

            if (rowsAffected > 1) {
                System.out.println("Payment OK. ");
                event.reply("done").queue();
            } else {
                System.out.println("no line updated, check the query.");
                event.reply("Error").queue();
            }

            System.out.println("Query requested by" + event.getMember().getEffectiveName() );



        }



        if (event.getName().equals("payment") ){
            if (!event.getMember().getRoles().stream().anyMatch(role -> role.getId().equals(Token.AdminRoleID)) ) {
                event.reply("You are not allowed to do such action").queue();
                return;
            }

            String PayerNat = event.getOption("nation1").getAsString();
            String ReceivingNat = event.getOption("nation2").getAsString();
            int amount = event.getOption("amount").getAsInt();

            if (amount < 0)
                amount *= -1;


            String balanceQuery = "SELECT Bank FROM nations WHERE ID = '" + PayerNat + "'";
            List<List<String>> result = DatabaseLoader.ReturnQuery(balanceQuery);
            if (result.isEmpty()) {
                event.reply("Payer nation's ID not found in the database.").queue();
                return;
            }

            double payerBank = Double.parseDouble(result.get(0).get(0));
            if (payerBank < amount) {
                event.reply("The payer nation does not have enough funds to complete this transaction.").queue();
                return;
            }

            System.out.println("nation payment: " + PayerNat + " payed " + amount + " to " + ReceivingNat );

            String query = "UPDATE nations SET Bank = Bank - ? WHERE ID = ?";
            int rowsAffected = DatabaseLoader.executeUpdateSimple(query, amount, PayerNat);
            query = "UPDATE nations SET Bank = Bank + ? WHERE ID = ?";
            rowsAffected += DatabaseLoader.executeUpdateSimple(query, amount, ReceivingNat);

            if (rowsAffected > 1) {
                System.out.println("Payment OK. ");
                event.reply("done").queue();
            } else {
                System.out.println("no line updated, check the query.");
                event.reply("Error").queue();
            }

            System.out.println("Query requested by" + event.getMember().getEffectiveName() );



        }

        if (event.getName().equals("alterbank") ){
            if (!event.getMember().getRoles().stream().anyMatch(role -> role.getId().equals(Token.AdminRoleID)) ) {
                event.reply("You are not allowed to do such action").queue();
                return;
            }

            String PayerNat = event.getOption("nation").getAsString();
            int amount = event.getOption("amount").getAsInt();


            String balanceQuery = "SELECT Bank FROM nations WHERE ID = '" + PayerNat + "'";
            List<List<String>> result = DatabaseLoader.ReturnQuery(balanceQuery);
            if (result.isEmpty()) {
                event.reply("Payer nation's ID not found in the database.").queue();
                return;
            }

            double payerBank = Double.parseDouble(result.get(0).get(0));

            System.out.println("Altered nations balance, ID: " + PayerNat +" bank was altered by " + amount);

            String query = "UPDATE nations SET Bank = Bank - ? WHERE ID = ?";
            int rowsAffected = DatabaseLoader.executeUpdateSimple(query, amount, PayerNat);

            if (rowsAffected > 1) {
                System.out.println("Payment OK. ");
                event.reply("done").queue();
            } else {
                System.out.println("no line updated, check the query.");
                event.reply("Error").queue();
            }

            System.out.println("Query requested by" + event.getMember().getEffectiveName() );

        }
    }



    public static void UpsertPaymentCommands(Guild g){
        g.upsertCommand("forcepayment", "forces a nation to pay a set sum of money to a different one, works without checks").addOptions(
                new OptionData(OptionType.STRING, "nation1", "the ID of the nation who PAYS the amount", true),
                new OptionData(OptionType.INTEGER, "amount", "the amount of cash", true),
                new OptionData(OptionType.STRING, "nation2", "the ID of the nation who GETS the amount", true)
        ).queue();

        g.upsertCommand("payment", "Make a nation pay a set sum of money to a different one").addOptions(
                new OptionData(OptionType.STRING, "nation1", "the ID of the nation who PAYS the amount", true),
                new OptionData(OptionType.INTEGER, "amount", "the amount of cash", true).setMinValue(0),
                new OptionData(OptionType.STRING, "nation2", "the ID of the nation who GETS the amount", true)
        ).queue();

        g.upsertCommand("alterbank", "alter the values inside a nations bank using the ID").addOptions(
                new OptionData(OptionType.STRING, "nation", "the ID of the nation who PAYS the amount", true).setMinValue(3).setMaxLength(3),
                new OptionData(OptionType.INTEGER, "amount", "the amount of cash to modify, positive for monetary gain and negative for monetary loss", true)
        ).queue();
    }
}

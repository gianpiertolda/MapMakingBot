USE nationsdb;

update provinces set localGDP = 100000 where province_id = 1;
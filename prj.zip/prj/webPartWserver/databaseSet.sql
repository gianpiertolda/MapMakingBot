CREATE DATABASE nationsdb;
USE nationsdb;

CREATE TABLE nations (
    ID CHAR(3) PRIMARY KEY,
    nation_name VARCHAR(25),    
    associatedPasscode VARCHAR(10) DEFAULT '12345678',
    lorePath VARCHAR(55) NOT NULL,
    armySize INT(10) DEFAULT 0,
    Bank float(13, 2) DEFAULT 0
);

CREATE TABLE provinces (
    province_id INT PRIMARY KEY,
    nation_id CHAR(3),
    province_name VARCHAR(50),
    localPop INT,
    localGDP DECIMAL(10, 2),
    compliance DECIMAL(5, 2),
    FOREIGN KEY (nation_id) REFERENCES nations(ID)
);

CREATE TABLE navy (
    navy INT PRIMARY KEY,
    nation_id CHAR(3),
    totalBattleships INT,/*TO add more vesssels type*/
    otherWeapons DECIMAL(5, 2),
    FOREIGN KEY (nation_id) REFERENCES nations(ID)
);

/* some starting nations */
INSERT INTO nations (ID, nation_name, associatedPasscode, lorePath, Bank, armySize) VALUES
('FRA', 'France', 'viveFrance22', 'nations/FranceLore.html', 150000000, 500000),
('GER', 'Germany', 'deutsch456', 'nations/GermanyLore.html', 80000000, 100000),
('RUS', 'Russia', 'soviet123', 'nations/RussiaLore.html', 50000000, 2000000),
('ENG', 'United Kingdom', 'ukpower789', 'nations/UnitedKingdomLore.html', 200000000, 700000),
('ITA', 'Italy', 'roma1922', 'nations/ItalyLore.html', 100000000, 300000),
('SPA', 'Spain', 'espanol456', 'nations/SpainLore.html', 30000000, 150000),
('POL', 'Poland', 'polska987', 'nations/PolandLore.html', 25000000, 400000),
('AUT', 'Austria', 'wien123', 'nations/AustriaLore.html', 15000000, 30000),
('BEL', 'Belgium', 'bruxelles22', 'nations/BelgiumLore.html', 20000000, 100000),
('GRE', 'Greece', 'hellas456', 'nations/GreeceLore.html', 12000000, 150000),
('TUR', 'Turkey', 'ankara1923', 'nations/TurkeyLore.html', 25000000, 350000),
('POR', 'Portugal', 'lisboa123', 'nations/PortugalLore.html', 10000000, 50000),
('NOR', 'Norway', 'oslo456', 'nations/NorwayLore.html', 8000000, 25000),
('SWE', 'Sweden', 'stockholm987', 'nations/SwedenLore.html', 15000000, 50000),
('NED', 'Netherlands', 'amsterdam22', 'nations/NetherlandsLore.html', 30000000, 75000),
('FIN', 'Finland', 'suomi123', 'nations/FinlandLore.html', 5000000, 40000);


/* random testing provinces */
INSERT INTO provinces (nation_id, province_id, province_name, localPop, localGDP, compliance) VALUES
('FRA', 1, 'Ile-de-France', 12000000, 31500000.50, 95.0),
('FRA', 2, 'Provence-Alpes', 5000000, 150000.30, 88.0),
('FRA', 3, 'Alsace', 3200000, 180000.30, 65.0),
('FRA', 4, 'Lorraine', 2800000, 90000.80, 60.0),
('FRA', 5, 'Brittany', 3000000, 100000.00, 85.0),
('FRA', 6, 'Normandy', 2800000, 110000.50, 87.0),
('FRA', 7, 'Occitanie', 4500000, 130000.00, 84.0),
('FRA', 8, 'Burgundy', 2500000, 85000.00, 82.0),
('FRA', 9, 'Aquitaine', 3500000, 90000.00, 83.0),
('FRA', 10, 'Corsica', 300000, 15000.00, 80.0),
('GER', 11, 'Bavaria', 13000000, 320000.20, 92.0),
('GER', 12, 'Berlin', 6000000, 180000.75, 89.0),
('GER', 13, 'Prussia', 35000000, 400000.00, 90.0),
('GER', 14, 'Saxony', 5000000, 150000.20, 85.0),
('GER', 15, 'Rhineland', 6000000, 200000.30, 70.0),
('GER', 16, 'Baden-Württemberg', 11000000, 220000.50, 88.0),
('GER', 17, 'Hamburg', 2000000, 75000.00, 93.0),
('GER', 18, 'Hanover', 4000000, 120000.00, 86.0),
('ITA', 19, 'Lombardia', 8000000, 180000.00, 93.0),
('ITA', 20, 'Sicilia', 5000000, 120000.00, 80.0),
('ITA', 21, 'Piemonte', 4000000, 130000.50, 88.0),
('ITA', 22, 'Campania', 6000000, 100000.00, 75.0),
('ITA', 23, 'Veneto', 3500000, 110000.25, 85.0),
('ITA', 24, 'Toscana', 3500000, 115000.00, 87.0),
('ITA', 25, 'Emilia-Romagna', 4000000, 125000.00, 89.0),
('ITA', 26, 'Puglia', 4000000, 95000.00, 80.0),
('ITA', 27, 'Sardegna', 1200000, 45000.00, 77.0),
('ENG', 28, 'England', 38000000, 500000.00, 93.0),
('ENG', 29, 'Scotland', 5400000, 150000.00, 90.0),
('ENG', 30, 'Wales', 3000000, 80000.00, 87.0),
('ENG', 31, 'Northern Ireland', 1600000, 50000.00, 75.0),
('ENG', 32, 'Ireland', 4500000, 85000.00, 65.0),
('RUS', 33, 'Moscow', 11000000, 250000.00, 70.0),
('RUS', 34, 'Saint Petersburg', 7000000, 200000.00, 75.0),
('RUS', 35, 'Ukraine', 25000000, 180000.00, 60.0),
('RUS', 36, 'Belarus', 8000000, 90000.00, 65.0),
('RUS', 37, 'Siberia', 15000000, 50000.00, 50.0),
('RUS', 38, 'Caucasus', 6000000, 75000.00, 58.0),
('RUS', 39, 'Central Asia', 12000000, 40000.00, 55.0),
('RUS', 40, 'Volga Region', 10000000, 120000.00, 68.0),
('RUS', 41, 'Urals', 6000000, 70000.00, 62.0),
('RUS', 42, 'Far East', 3000000, 30000.00, 45.0);
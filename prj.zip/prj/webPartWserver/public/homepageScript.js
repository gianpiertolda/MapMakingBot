const nationInput = document.getElementById('nation');
const passwordInput = document.getElementById('password');
const loginButton = document.querySelector('button');

loginButton.addEventListener('click', async function(event) {
    event.preventDefault();

    const nationName = nationInput.value.trim();
    const accessCode = passwordInput.value.trim();

    if (nationName === "" || accessCode === "") {
        document.getElementById('insert-text').innerText = "Please fill in both fields.";
        return;
    }

    try {
        const response = await fetch('/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ nationName, accessCode })
        });

        const result = await response.json();

        if (response.ok) {
            document.getElementById('insert-text').innerText = "Login authorized, redirecting...";
            sessionStorage.setItem("authToken", nationName);
            window.location.href = result.redirectPath;
        } else {
            document.getElementById('insert-text').innerText = `Invalid login for Nation: ${nationName} with Code: ${accessCode}`;
        }
    } catch (error) {
        console.error("Error:", error);
        document.getElementById('insert-text').innerText = "An error occurred while logging in.";
    }
});

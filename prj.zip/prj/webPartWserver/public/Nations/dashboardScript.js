if (sessionStorage.getItem("authToken") == null){
    document.getElementById('body').innerHTML = '<p> please log in first </p>'
    alert('please log in first');
    window.location.href = "../home.html";
}

let Provinces;
let totalPop;
let adjProvinces;
let totalBank;
let armySize;
let nation = getNatNameBySessionStorage();
let pathToLore;

function totalPopFromProvinces(prov) {
    let count = 0;
    for (let p of prov) {
        count += p.localPop;
    }
    return count;
}

if (!nation) {
    console.error("Nation name is not defined. Redirecting to login...");
    window.location.href = "../home.html";
}

function getNatNameBySessionStorage() {
    if (sessionStorage.getItem("authToken") !== null) {
        return sessionStorage.getItem("authToken");
    }
    alert("Invalid session. Please log in again.");
    window.location.href = "../home.html";
    return null;
}

fetch('/provinces/'+nation)
    .then(response => {
        if (!response.ok) {
            throw new Error("Failed to load stats.");
        }
        return response.json();
    })
    .then(data => {
        // Conserva i dati delle province e calcola la popolazione totale
        Provinces = data.provinces;
        console.log("loaded provinces", Provinces);
        totalPop = totalPopFromProvinces(Provinces);
        console.log("Total Nation Population:", totalPop);
    
        adjProvinces = adjustByCompliance(Provinces);

        populateTable(adjProvinces);
    })
    .catch(error => {
        document.getElementById('error-div').style.visibility = "visible";
        document.getElementById('error-div').innerText = "Error loading stats.";
        console.error("Error fetching stats:", error);
    });

fetch('/generalStats/'+nation)
    .then(response => {
        if(!response.ok){
            throw new Error("Failed to load stats.");
        }
        return response.json();
    })
    .then(data =>{
        console.log("loaded raw data for the nation");
        totalBank = data.Bank;
        console.log("bank: ", totalBank);
        setNatBank(totalBank);
        armySize = data.armySize;
        setArmy(armySize);
        console.log(nation);
        pathToLore = data.lorePath;
        insertNationNameInDocument();

    })
    .catch(error =>{
        document.getElementById('error-div').style.visibility = "visible";
        document.getElementById('error-div').innerText = "Error loading stats.";
        document.getElementById('natBank').innerText = 'unable to load national Bank values from the server';
        console.error("Error fetching stats:", error);
});

// Classe per rappresentare una Provincia
class ProvinceClass {
    constructor(name, localPop, localGDP, compliance) {
        this.name = name;
        this.localPop = localPop;
        this.localGDP = localGDP;
        this.compliance = compliance;
        this.gdpPerCapita = (localPop > 0) ? (localGDP / localPop).toFixed(2) : "N/A";
    }
}

// function to populate table
function populateTable(provinces) {
    const tableBody = document.querySelector("#Stats-Table-full tbody");

    tableBody.innerHTML = "";

    // 1st row
    const headerRow = `
        <tr>
            <th>Province</th>
            <th>Population</th>
            <th>Local GDP</th>
            <th>GDP/capita</th>
            <th>Compliance</th>
        </tr>`;
    tableBody.innerHTML += headerRow;

    provinces.forEach(prov => {
        const province = new ProvinceClass(prov.province_name, prov.localPop, prov.localGDP, prov.compliance);
        
        const row = `
            <tr>
                <td>${province.name}</td>
                <td>${province.localPop}</td>
                <td>${province.localGDP}</td>
                <td>${province.gdpPerCapita}</td>
                <td>${province.compliance}%</td>
            </tr>`;
        
        tableBody.innerHTML += row;
    });
}

function adjustByCompliance(provinces) {
    return provinces.map(prov => {
        if (prov.compliance <= 50) {
            prov.localGDP = (prov.localGDP * (prov.compliance / 100)).toFixed(2);
        }
        return prov;
    });
}

function setNatBank(value){
    document.getElementById('natBank').innerText = value;
}

function setArmy(value){
    document.getElementById('armySize').innerText = value;
}

function insertNationNameInDocument(){
    document.getElementById('title').innerHTML = nation;
    document.title = nation + document.title;
}

function insertLoreInDocumentWithPath(path){
    
}
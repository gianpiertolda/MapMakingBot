if (sessionStorage.getItem("authToken") !== "Superuser") {
    alert("You are not authorized to view this page.");
    window.location.href = "../../home.html";
}

let Provinces;

fetch('/AdminRequest')
    .then(response => {
        if (!response.ok) {
            throw new Error("Failed to load stats.");
        }
        return response.json();
    })
    .then(data => {
        Provinces = data.provinces;
        console.log("provinces loaded form the server:", Provinces);
        populateTable(Provinces);
    })
    .catch(error => {
        document.getElementById('error-div').style.visibility = "visible";
        document.getElementById('error-div').innerText = "Error loading stats.";
        console.error("Error fetching stats:", error);
    });


    class ProvinceClass {
        constructor(nation_id, name, localPop, localGDP, compliance) {
            this.nation_id = nation_id;
            this.name = name;
            this.localPop = localPop;
            this.localGDP = localGDP;
            this.compliance = compliance;
            this.gdpPerCapita = (localPop > 0) ? (localGDP / localPop).toFixed(2) : "N/A";  // Calcola GDP per capita
        }
    }

function populateTable(provinces) {
        const tableBody = document.querySelector("#Stats-Table-full tbody");
    
        // Pulisce il contenuto esistente
        tableBody.innerHTML = "";
    
        // Riga di intestazione
        const headerRow = `
            <tr>
                <th>owner nation</th>
                <th>Province</th>
                <th>Population</th>
                <th>Local GDP</th>
                <th>GDP per capita</th>
                <th>Compliance</th>
            </tr>`;
        tableBody.innerHTML += headerRow;
    
        var temp = "";
        provinces.forEach(prov => {
            const province = new ProvinceClass(prov.nation_id,prov.province_name, prov.localPop, prov.localGDP, prov.compliance);
            
            if(temp != province.nation_id){
                tableBody.innerHTML += `<tr><td colspan="6" style="height: 10px;"></td></tr>`;
            }

            temp = province.nation_id;

            const row = `
                <tr>
                    <td>${province.nation_id}</td>
                    <td>${province.name}</td>
                    <td>${province.localPop}</td>
                    <td>${province.localGDP}</td>
                    <td>${province.gdpPerCapita}</td>
                    <td>${province.compliance}%</td>
                </tr>`;

            tableBody.innerHTML += row;
        });
    }
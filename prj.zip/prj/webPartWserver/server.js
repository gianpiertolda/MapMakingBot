const express = require('express');
const path = require('path');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const cron = require('node-cron');

const app = express();
const PORT = 3000;

// mySql credential
const db = mysql.createConnection({
    host: 'localhost',      // localhost if you are on the same machine, if not insert the public IP
    user: 'root',           // this is the user name, if not changed is 'root'
    password: '',           // this is the password
    database: 'nationsdb'   // this is the name of the database
});

// database connection
db.connect((err) => {
    if (err) {
        console.error('Errore di connessione al database:', err);
        return;
    }
    console.log('Connesso al database MySQL.');
});

//middlewere handling
app.use(express.static('public'));
app.use(bodyParser.json());

// default HTML route (routing to the login page)
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'home.html'));
});

//post for login handling
app.post('/login', (req, res) => {
    const { nationName, accessCode } = req.body;

    // check for superuser credential
    if (nationName === "Superuser" && accessCode === "1234") {
        return res.json({ redirectPath: "/adminDashboard.html" });
    }

    // database credential for player
    db.query(
        'SELECT lorePath FROM nations WHERE nation_name = ? AND associatedPasscode = ?',
        [nationName, accessCode],
        (error, results) => {
            if (error) {
                console.error('Errore nella query:', error);
                return res.status(500).json({ message: "Errore del server." });
            }

            if (results.length > 0) {
                const lorePath = results[0].lorePath;
                res.json({ redirectPath: 'Nations/DashBoard.html' });
            } else {
                res.status(401).json({ message: "Nome o codice errato." });
            }
        }
    );
});

// route for getting all the provinces of a specific nation
app.get('/provinces/:nationName', (req, res) => {
    const nationName = req.params.nationName;
    if (!nationName) {
        return res.status(400).json({ message: "Nome della nazione non fornito." });
    }

    db.query('SELECT ID FROM nations WHERE nation_name = ?', [nationName], (error, results) => {
        if (error) {
            console.error('Errore nella query:', error);
            return res.status(500).json({ message: "Errore del server." });
        }

        if (results.length === 0) {
            return res.status(404).json({ message: "Nazione non trovata." });
        }

        const nationId = results[0].ID;
        db.query('SELECT province_name, localPop, localGDP, compliance FROM provinces WHERE nation_id = ?', [nationId], (err, provinceStats) => {
            if (err) {
                console.error('Errore nella query delle province:', err);
                return res.status(500).json({ message: "Errore del server durante il recupero delle statistiche." });
            }
            res.json({ provinces: provinceStats });
        });
    });
});

app.get('/generalStats/:nationName', (req, res) => {
    const nationName = req.params.nationName;

    // gets the general nation's information from the name
    db.query(
        'SELECT * FROM nations WHERE nation_name = ?',
        [nationName],
        (error, results) => {
            if (error) {
                console.error('Errore nella query:', error);
                return res.status(500).json({ message: "Errore del server." });
            }

            if (results.length > 0) {
                res.json(results[0]);
            } else {
                res.status(404).json({ message: "Nazione non trovata." });
            }
        }
    );
});

app.get('/AdminRequest', (req, res) => {
    db.query(
        'SELECT nation_id, province_name, localPop, localGDP, compliance FROM provinces',
        (err, provinceStats) => {
            if (err) {
                console.error('Errore nella query delle province:', err);
                return res.status(500).json({ message: "Errore del server durante il recupero delle statistiche." });
            }
            res.json({ provinces: provinceStats });
        }
    );
});

function startYearUpdateScheduler(database) {
    cron.schedule('0 0 */2 * *', () => {//          * CRON handling for a 2 days scheduler
    //cron.schedule('* * * * *', () => {            * CRON test handling with 60s tick
        console.log(`Year update triggered at ${new Date().toISOString()}`);
        updateYear(database);
    });

    console.log('Year update scheduler started. It will run every 48 hours.');
}



function updateYear(database) {
    // excecute both queries at the same time with 'Promise'
    const nationsPromise = new Promise((resolve, reject) => {
        database.query("SELECT * FROM nations", (err, res) => {
            if (err) {
                console.error("Update error on nations at: " + Date.now());
                return reject(err);
            }
            resolve(res);
        });
    });

    const provincesPromise = new Promise((resolve, reject) => {
        database.query("SELECT * FROM provinces", (err, res) => {
            if (err) {
                console.error("Update error on provinces at: " + Date.now());
                return reject(err);
            }
            resolve(res);
        });
    });

    // waits for promises to return the values
    Promise.all([nationsPromise, provincesPromise])
        .then(([nationsData, provincesData]) => {
            console.log("Nations and Provinces data retrieved successfully.");
            nationsData.forEach((nation) => {
                const nationId = nation.ID;
                const armySize = parseInt(nation.armySize, 10) || 0;

                const economy = calculateTotalEconomyFromProvinces(nationId, provincesData);
                const updatedBank = economy - (armySize * 850);

                // update the BANK from the database
                database.query(
                    "UPDATE nations SET Bank = Bank + ? WHERE ID = ?",
                    [updatedBank, nationId],
                    (err, result) => {
                        if (err) {
                            console.error("Error updating nation " + nationId + ": " + err.message);
                        } else {
                            console.log("Updated bank for nation: " + nationId);
                        }
                    }
                );
            });
        })
        .catch((err) => {
            console.error("Error retrieving data: " + err.message);
        });
}

function calculateTotalEconomyFromProvinces(nationId, provincesData) {
    let totalEconomy = 0;
    provincesData.forEach((province) => {
        if (province.nation_id === nationId) {
            totalEconomy += parseFloat(province.localGDP) || 0;
        }
    });
    return totalEconomy;
}


// server start
app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});

startYearUpdateScheduler(db);
